document.getElementById('convertBtn').addEventListener('click', function() {
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const originalUrl = tabs[0].url;
    const url = new URL(originalUrl);
    if (url.pathname.includes('_layouts/15/onedrive.aspx')) {
      const newUrl = url.searchParams.get('id');
      if (newUrl) {
        const simplifiedUrl = `https://${url.host}${decodeURIComponent(newUrl)}`;
        chrome.tabs.create({ url: simplifiedUrl });
      }
    }
  });
});
