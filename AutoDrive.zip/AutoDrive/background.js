chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    if (changeInfo.url && changeInfo.status === 'loading') {
      const url = new URL(changeInfo.url);
      if (url.pathname.includes('_layouts/15/onedrive.aspx')) {
        const idParam = url.searchParams.get('id');
        if (idParam) {
          // Check if the URL ends with document file extensions
          const fileMatch = idParam.match(/\.pdf$|\.docx$|\.xlsx$/i);
          if (fileMatch) {
            const simplifiedUrl = `https://${url.host}${decodeURIComponent(idParam)}`;
            // Open the URL in a new tab
            chrome.tabs.create({url: simplifiedUrl});
          }
        }
      }
    }
  });

  



